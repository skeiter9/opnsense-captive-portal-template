/**
 * This file has been deprecated and integrated into the main CaptivePortalAPI class.
 * All functions have been modernized and moved to js/api.js
 * 
 * @deprecated Use CaptivePortalAPI class instead
 */

// This file is kept for compatibility but is no longer used
// All functionality has been moved to the CaptivePortalAPI class in api.js
console.warn('functions.js is deprecated. Functionality moved to CaptivePortalAPI class.');